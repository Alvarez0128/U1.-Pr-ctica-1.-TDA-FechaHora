
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author César Álvarez
 */
public class FechaHora {
    private int dia;
    private int mes;
    private int anyo;
    private int hora;
    private int minuto;

    public FechaHora hoy(){
        int d,m,min,h;
        do{
            d=Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese el día"));
            if(d>=1 && d<=31){
                dia+=d;
            }else{
                JOptionPane.showMessageDialog(null, "Ingrese un número dentro del rango de dias de un mes");
            }
        }while(d>31 || d<1);    
        
        do{
            m=Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese el mes"));
            if(m>=1 && m<=12){
                mes+=m;
            }else{
                JOptionPane.showMessageDialog(null, "Ingrese un número de mes válido!");
            }
        }while(m>12 || m<1);   
        
        anyo = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese el año"));
        
        do{
            h=Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese la hora"));
            if(h>=0 && h<24){
                hora+=h;
            }else{
                JOptionPane.showMessageDialog(null, "Ingrese una hora válida!");
            }
        }while(h<0 || h>24);
    
        do{
            min=Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese el minuto"));
            if(min>=0 && min<60){
                minuto+=min;
            }else{
                JOptionPane.showMessageDialog(null, "Ingrese un número dentro del rango de un minuto");
            }
        }while(min<0 || min>59);
        return null;
    }
    public String fechaLarga(){
        String m="";
        String min;
        String M[]={"mes","Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto"
                ,"Septiembre","Octubre","Noviembre","Diciembre"};
        for(int i=0;i<M.length;i++){
            if(mes==i){
                m+=M[i];
            }
        }
        min=String.format("%02d", minuto);
        JOptionPane.showMessageDialog(null, "Fecha Larga: "+dia+ " de "+m+
                " del año "+anyo+"  "+hora+":"+min);
        return null;
    } 
    public String fechaCorta(){
        String d,m,min;
        d=String.format("%02d", dia);
        m=String.format("%02d", mes);
        min=String.format("%02d", minuto);
        JOptionPane.showMessageDialog(null, "Fecha Corta: "+d+ "/"+m+
                "/"+anyo+"  "+hora+":"+min);
        return null;
    }
    public String Formato24(){
        String min;
        min=String.format("%02d", minuto);
        if(hora>=0 && hora<12){
            JOptionPane.showMessageDialog(null, "Formato 24 hrs: "+ hora+":"+min+" am");
        }else{
            JOptionPane.showMessageDialog(null, "Formato 24 hrs: "+ hora+":"+min+" pm");
        }
        return null;
    }
    
    public String Formato12(){
        String min,h;
        min=String.format("%02d", minuto);
        h=String.format("%02d", hora);
        if(hora>=0 && hora<12){
            JOptionPane.showMessageDialog(null, "Formato 12 hrs: "+ h+":"+min+" am");
        }else{
            h=String.format("%02d", hora%2);
            JOptionPane.showMessageDialog(null, "Formato 12 hrs: "+ h+":"+min+" pm");
        }
        
        return null;
    }
}
